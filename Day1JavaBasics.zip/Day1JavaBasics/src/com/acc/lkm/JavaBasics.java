package com.acc.lkm;

public class JavaBasics {
	 String x="Accenture";

	public static void main(String[] args) {
		JavaBasics j=new JavaBasics();
		//j.x="KDC";
		System.out.println(j.x);

	}

}
