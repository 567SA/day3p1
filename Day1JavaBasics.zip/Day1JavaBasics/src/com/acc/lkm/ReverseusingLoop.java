package com.acc.lkm;
import java.util.Scanner;
public class ReverseusingLoop {
public static void main(String args[]) {
	Scanner scan=new Scanner(System.in);
	int num,digit,reverse=0;
	System.out.println("Enter any number:");
	num=scan.nextInt();
	while(num>0) {
		digit=num%10;
		reverse=reverse*10+digit;
		num/=10;
		
	}
	System.out.println("Reverse num is:"+reverse);
	
}
}
