package com.acc.lkm;
import java.util.Scanner;
public class ControlStatementDemo {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number:");
		int num=scan.nextInt();
		if(num%2==0) {
			System.out.println("Num is even");
		}
		else {
			System.out.println("Num is odd");
		}

	}

}
