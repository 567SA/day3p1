package com.acc.lkm;
import com.acc.Simple.*;

public class Access {
	public static void main(String args[] ){
		Cricketer cricketer=new Cricketer();
		cricketer.show("MS Dhoni","INDIA", 38, "Brown","WicketKeeper", "Jharkhand");
		cricketer.bat();
		cricketer.wckt();
	}
}
