package com.acc.lkm;
import java.util.Scanner;

public class ScannerDemo {
	public static void main(String args[]) {
		/*ConstDemo con=new ConstDemo();
		System.out.println(con.disp(32));*/
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the name:");
		String name=scan.next();
		System.out.println("Enter the EID:");
		long eid=scan.nextLong();
		System.out.println("Name is :"+name+"\n"+"EID is :"+eid);
		
	}
}
