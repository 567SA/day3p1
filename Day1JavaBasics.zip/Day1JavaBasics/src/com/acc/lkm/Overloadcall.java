package com.acc.lkm;
import java.util.Scanner;
public class Overloadcall {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the name:");
		String name=scan.next();
		System.out.println("Enter the First Num:");
		Long num1=scan.nextLong();
		System.out.println("Enter the Second Num:");
	    Long num2=scan.nextLong();
	    MethodOverloadingDemo demo=new MethodOverloadingDemo();
	    demo.contact(name, num1);
	    demo.contact(name, num1, num2);

	}

}
