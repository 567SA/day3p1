package com.acc.lkm;

public class LoopDemo {
public static void main(String args[]) {
	for(int x=1;x<=5;x++) {
		for(int y=1;y<=x;y++) {
		System.out.print(" *");
	}
		System.out.println();
	//System.out.println(x);
}
}}

