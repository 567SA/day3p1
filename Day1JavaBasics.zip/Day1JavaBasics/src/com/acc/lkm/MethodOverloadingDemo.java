package com.acc.lkm;

public class MethodOverloadingDemo {

	public void contact(String name,Long Num1) {
		System.out.println("Name is:"+name+"\n"+"Num1 is :"+Num1);
	}
	public void contact(String name,Long Num1,Long Num2) {
		System.out.println("Name is:"+name+"\n"+"Num1 is :"+Num1+"\n"
				+"Num2 is:"+Num2);
	}
}
