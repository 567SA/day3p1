package com.acc.lkm;
import java.util.Scanner;
public class ArrayDemo {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int len;
		System.out.println("Enter the length:");
	    len=scan.nextInt();
	    int x[]=new int[len+1];
	    System.out.println("Enter the elements:");
	    for(int i=0;i<len;i++) {
	    	x[i]=scan.nextInt();}
	    	System.out.println("Enter the element you want to insert:");
	    	int ele=scan.nextInt();
	    	x[len]=ele;
	    	System.out.println("After inserting: ");
	    	for( int i=0;i<len;i++) {
	    		System.out.println(x[i]+",");
	    	}
	    	System.out.println(x[len]);
	    }
	    
		

	}


