package com.acc.lkm;
import java.util.Scanner;
public class EncapsulationDemo {
	private int OTP,CVV;
	String CardHolder;
	private int getOTP() {
		return OTP;
	}
	private void setOTP(int oTP) {
		OTP = oTP;
	}
	private int getCVV() {
		return CVV;
	}
	private void setCVV(int cVV) {
		CVV = cVV;
	}
	private String getCardHolder() {
		return CardHolder;
	}
	private void setCardHolder(String cardHolder) {
		CardHolder = cardHolder;
	}
public static void main(String args[]) {
	Scanner scan=new Scanner(System.in);
	EncapsulationDemo encap=new EncapsulationDemo();
	System.out.println("Enter the OTP");
	int otp=scan.nextInt();
	System.out.println("Enter the CVV");
	int cvv=scan.nextInt();
	System.out.println("Enter the Name");
	String name=scan.next();
	encap.setCardHolder(name);
	encap.setCVV(cvv);
	encap.setOTP(otp);
	System.out.println("CardHolder is:"+encap.getCardHolder()+"\n"+"Your OTP is:"
			+encap.getOTP()+"\n"+"CVV is:"+encap.getCVV());
	
	
}
}
