package com.acc.lkm;
import java.util.Scanner;
public class Array2Demo {

	public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	double total=0,percentage;
	int n,marks;
	System.out.println("Enter the length:");
	n=scan.nextInt();
	int x[]=new int[n];
	System.out.println("Enter the marks:");
	for(int i=0;i<n;i++) {
	 x[i]=scan.nextInt();
	 total+=x[i];
	
	}
	 System.out.println("Total marks:"+total);
	 percentage=total/n;
	 System.out.println(percentage);
	}

}
