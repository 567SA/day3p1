package com.acc.lkm;
import java.util.Scanner;
public class SwitchDemo {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the day no:");
		int day=scan.nextInt();
		switch(day) {
		
		case 1: System.out.println("Day is Monday");
		break;
		case 2: System.out.println("Day is Tues");
		break;
		case 3: System.out.println("Day is Wed");
		break;
		case 4: System.out.println("Day is Thurs");
		break;
		case 5: System.out.println("Day is Fri");
		break;
		case 6: System.out.println("Day is Sat");
		break;
		case 7: System.out.println("Day is Sun");
		break;
		default:
			System.out.println("Invalid input");
		
		
		}

	}

}
