package com.acc.lkm;
import java.lang.*;
import java.util.Scanner;

public class ConstDemo {
static double Area,rad;
 static final double pi=3.14;
 double disp(double radius) {
	 rad=radius;
		Area= pi*Math.pow(rad, 2);
		//System.out.println("Area of the Circle is:"+Area); 
		return Area;
 }
/*public ConstDemo(double radius) {
	rad=radius;
	Area= pi*Math.pow(rad, 2);
	System.out.println("Area of the Circle is:"+Area);
}*/

public static void main(String args[]) {
	/*ConstDemo con=new ConstDemo();
	System.out.println(con.disp(32));*/
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter the Radius:");
	double rad=scan.nextDouble();
	Area= pi*Math.pow(rad, 2);
	System.out.println("Area of the Circle is:"+Area);
}
}
