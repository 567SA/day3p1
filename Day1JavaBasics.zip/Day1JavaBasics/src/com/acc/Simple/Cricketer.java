package com.acc.Simple;

public class Cricketer {
	String name;
	String Country;
	int age;
	String Color;
	String Role;
	String State;
	
	public void show(String n,String coun,int a,String clr,String rl,String st) {
		name=n;
		Country=coun;
		age=a;
		Color=clr;
		Role=rl;
		State=st;
		System.out.println(name+"\n"+Country+"\n"+age+"\n"+Color+"\n"+Role+"\n"+State);
		
		
	}
	
	public void bat() {
		System.out.println("He can Bat");
	}
	public void wckt() {
		System.out.println("He can do wicketkeeping");
	}

}
